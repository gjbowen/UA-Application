create procedure p_sendemail (email_addr IN varchar2,
                       email_to_name IN varchar2,
                       email_from_addr IN varchar2,
                       email_from_name IN varchar2,
                       email_host IN varchar2,
                       email_subject IN varchar2,
                       email_message IN varchar2,
                       email_success IN OUT varchar2,
                       email_reply IN OUT varchar2,
                       email_error_type OUT VARCHAR2,
                       email_error_code OUT VARCHAR2,
                       email_error_message OUT VARCHAR2)
is
    mail_conn     utl_smtp.connection;
    lv_reply      utl_smtp.reply;
    lv_replies    utl_smtp.replies;
    lv_debug_msg  VARCHAR2(1000);
    crlf VARCHAR2( 2 ):= CHR( 13 ) || CHR( 10 );
    replymsg      utl_smtp.reply;
    send_text     varchar2(5000) := '';
    to_text       varchar2(500) := '';
    from_text     varchar2(500) := '';
    subj_text     varchar2(100) := '';
    err_num       NUMBER;
    err_msg       VARCHAR2(100);

BEGIN
    send_text := '';
    to_text := '';
    from_text := '';
    subj_text := '';

    if email_to_name is not null then
      to_text := 'To: "' || email_to_name || '"<' || email_addr
          || '>' || crlf;
    else
      to_text :=  G$_NLS.Get('SOKEMA1-0000', 'SQL',
	'To: %01%%02%'
	,  email_addr ,   crlf);
    end if;

    if email_from_addr is not null then
       if email_from_name is not null then
       from_text := 'From: "' || email_from_name
          || '"<' || email_from_addr || '>' || crlf;
       else
        from_text :=  G$_NLS.Get('SOKEMA1-0001', 'SQL',
	'From: %01%%02%'
	,  email_from_addr ,  crlf);
       end if;
    end if;

    if email_subject is not null then
        subj_text :=   G$_NLS.Get('SOKEMA1-0002', 'SQL',
	'Subject: %01%%02%'
	,  email_subject ,  crlf);
    end if;

    send_text := to_text || from_text || subj_text || crlf || email_message || crlf;

    if email_host is null then
      email_success := 'F';
      email_reply :=  G$_NLS.Get('SOKEMA1-0003', 'SQL','*ERROR* Blank Mail Host') ;

      email_error_type := 'O';
      email_error_code := null;
      email_error_message := G$_NLS.Get('SOKEMA1-0004', 'SQL','*ERROR* Blank Mail Host');

      return;
    end if;

    if email_from_addr is null then
      email_success := 'F';
      email_reply :=  G$_NLS.Get('SOKEMA1-0005', 'SQL','*ERROR* Blank From Addr') ;

      email_error_type := 'O';
      email_error_code := null;
      email_error_message := G$_NLS.Get('SOKEMA1-0006', 'SQL','*ERROR* Blank From Addr');

      return;
    end if;

    mail_conn := utl_smtp.open_connection(email_host);
    utl_smtp.helo(mail_conn, email_host);
    utl_smtp.mail(mail_conn, email_from_addr);
    utl_smtp.rcpt(mail_conn, email_addr);
    utl_smtp.open_data(mail_conn);
    utl_smtp.write_data(mail_conn, send_text);
    utl_smtp.close_data(mail_conn);
    utl_smtp.quit(mail_conn);

    /* 1-7BFR7
       utl_smtp - above calls are procedure calls to API's, utlsmtp.sql also
       has overriden function calls; function calls can pass back smtp messages.
       If you need to debug sending of mail, you can comment out the above procedure
       API calls and substitute with the folling function API calls; these will give
       you any mail server error numbers to track down.

       lv_replies(1) := utl_smtp.helo(mail_conn, email_host);
       lv_replies(2) := utl_smtp.mail(mail_conn, email_from_addr);
       lv_replies(3) := utl_smtp.rcpt(mail_conn, email_addr);
       lv_replies(4) := utl_smtp.vrfy(mail_conn,email_addr);
       lv_replies(5) := utl_smtp.open_data(mail_conn);
       utl_smtp.write_data(mail_conn, send_text);
       lv_replies(7) := utl_smtp.close_data(mail_conn);
       lv_replies(8) := utl_smtp.quit(mail_conn);

       IF lv_replies.count > 0 THEN
          FOR j IN lv_replies.first..lv_replies.last
          LOOP
             lv_debug_msg := lv_replies(j).code || ' ' || lv_replies(j).text;
          END LOOP;
       END IF;

       Procedure API calls can raise the utl_smtp.transient_error and utl_smtp.permanent_error,
       where as function calls may not raise these errors.
    */

    email_success := 'T';
    email_reply :=  G$_NLS.Get('SOKEMA1-0007', 'SQL','Mail Sent') ;

  EXCEPTION
     WHEN utl_smtp.transient_error THEN
       BEGIN
         email_success := 'F';
         err_num := SQLCODE;
         err_msg := SUBSTR(SQLERRM, 1, 100);
         email_reply := '*ORA ERR*' || to_char(err_num) || ' ' || err_msg;

         email_error_type := 'T';
         email_error_code := to_char(err_num);
         email_error_message := SUBSTR(SQLERRM, 1, 300);

         utl_smtp.quit(mail_conn);

       EXCEPTION
         WHEN utl_smtp.transient_error OR utl_smtp.permanent_error THEN
           NULL;
                 -- When the SMTP server is down or unavailable, we don't
                 -- have a connection to the server. The quit call will
                 -- raise an exception that we can ignore.
                 -- I.E. server down, can't send reply message back.
        END;
     WHEN utl_smtp.permanent_error THEN
       BEGIN
         email_success := 'F';
         err_num := SQLCODE;
         err_msg := SUBSTR(SQLERRM, 1, 100);
         email_reply := '*ORA ERR*' || to_char(err_num) || ' ' || err_msg;

         email_error_code := to_char(err_num);
         email_error_message := SUBSTR(SQLERRM, 1, 300);
         IF to_char(SQLCODE)= to_char('-30678') THEN
           email_error_type := 'T';      /*If error is of -30678 too many open connections send it as transient error.*/
           --============================================
           BEGIN
             UTL_TCP.close_all_connections;/*If too many open connections then close all connections opened.*/
           EXCEPTION
             WHEN OTHERS THEN
               NULL;
           END;
           --============================================
         ELSE
           email_error_type := 'P';
         END IF;

         utl_smtp.quit(mail_conn);

       EXCEPTION
         WHEN utl_smtp.transient_error OR utl_smtp.permanent_error THEN
           NULL;
                 -- When the SMTP server is down or unavailable, we don't
                 -- have a connection to the server. The quit call will
                 -- raise an exception that we can ignore.
                 -- I.E. server down, can't send reply message back.
        END;
     WHEN OTHERS THEN
        BEGIN
        email_success := 'F';
        err_num := SQLCODE;
        err_msg := SUBSTR(SQLERRM, 1, 100);
        email_reply := '*ORA ERR*' || to_char(err_num) || ' ' ;

        email_error_code := to_char(err_num);
        email_error_message := SUBSTR(SQLERRM, 1, 300);
        IF to_char(SQLCODE)= to_char('-30678') THEN
          email_error_type := 'T';      /*If error is of -30678 too many open connections send it as transient error.*/
          --============================================
          BEGIN
            UTL_TCP.close_all_connections;/*If too many open connections then close all connections opened.*/
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;
          --============================================
        ELSE
          email_error_type := 'O';
        END IF;

        utl_smtp.quit(mail_conn);

       EXCEPTION
         WHEN utl_smtp.transient_error OR utl_smtp.permanent_error THEN
           NULL;
                 -- When the SMTP server is down or unavailable, we don't
                 -- have a connection to the server. The quit call will
                 -- raise an exception that we can ignore.
                 -- I.E. server down, can't send reply message back.
        END;

end p_sendemail;
/

