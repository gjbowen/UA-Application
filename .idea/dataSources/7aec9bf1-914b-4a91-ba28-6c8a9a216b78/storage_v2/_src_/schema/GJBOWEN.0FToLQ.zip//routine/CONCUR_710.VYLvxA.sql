create procedure         concur_710
is
     
    line  			            VARCHAR2(20000);
    file_out				    UTL_FILE.FILE_TYPE;

    file_name					VARCHAR2(50) := 'concur_employee_feed_710_full_'||to_char(sysdate,'mmddyyyy')||'.txt';
    v_dbname                    varchar2(10);
    v_pathout				    varchar2(16);

    v_concur_710_cwid           ua_fimsmgr.concur_710.concur_710_cwid%type;
    v_concur_710_coas           ua_fimsmgr.concur_710.concur_710_coas%type;
    v_concur_710_fund           ua_fimsmgr.concur_710.concur_710_fund%type;
    v_concur_710_orgn           ua_fimsmgr.concur_710.concur_710_orgn%type;
    v_concur_710_level          ua_fimsmgr.concur_710.concur_710_level%type;

    cursor c_cursor is 
    select distinct concur_710_cwid,concur_710_coas, concur_710_fund, concur_710_orgn, concur_710_level
    from ua_fimsmgr.concur_710
    where concur_710_version >0
    order by concur_710_coas,concur_710_fund,concur_710_orgn,concur_710_level;
    
BEGIN
 	v_pathout := '/u03/export/PROD';
	file_out := UTL_FILE.FOPEN(v_pathout,file_name,'w');
    UTL_FILE.PUT_LINE(file_out, '100,0,SSO,UPDATE,EN,N,N');
	open c_cursor;
    LOOP 
    fetch c_cursor into v_concur_710_cwid,v_concur_710_coas, v_concur_710_fund, v_concur_710_orgn, v_concur_710_level;
    exit when c_cursor%notfound; 
         line :='710'||',' ||   --col 1
                'EXP'||','||  --col 2
                v_concur_710_cwid   || ','|| --col3
                v_concur_710_coas  || ','|| --col 4
                v_concur_710_fund  ||','|| --col 5
                v_concur_710_orgn  ||','||--col 6
                ','||--col 7
                ','||--col 8
                ','||--col 9
                ','||--col 10
                ','||--col 11
                ','||--col 12
                ','||--col 13
                'N'||','||--col 14
                ','||--col 15
                'USD'||','||--col 16
                v_concur_710_level--col 17
                ;
        UTL_FILE.PUT_LINE(file_out, line);
        line :='710'||',' ||   --col 1
                'PMT'||','||  --col 2
                v_concur_710_cwid   || ','|| --col3
                v_concur_710_coas  || ','|| --col 4
                v_concur_710_fund  ||','|| --col 5
                v_concur_710_orgn  ||','||--col 6
                ','||--col 7
                ','||--col 8
                ','||--col 9
                ','||--col 10
                ','||--col 11
                ','||--col 12
                ','||--col 13
                'N'||','||--col 14
                ','||--col 15
                'USD'||','||--col 16
                v_concur_710_level--col 17
                ;
        UTL_FILE.PUT_LINE(file_out, line);
        line :='710'||',' ||   --col 1
                'REQ'||','||  --col 2
                v_concur_710_cwid   || ','|| --col3
                v_concur_710_coas  || ','|| --col 4
                v_concur_710_fund  ||','|| --col 5
                v_concur_710_orgn  ||','||--col 6
                ','||--col 7
                ','||--col 8
                ','||--col 9
                ','||--col 10
                ','||--col 11
                ','||--col 12
                ','||--col 13
                'N'||','||--col 14
                ','||--col 15
                'USD'||','||--col 16
                v_concur_710_level--col 17
                ;
        UTL_FILE.PUT_LINE(file_out, line);
    END LOOP;

    close c_cursor;

    UTL_FILE.FCLOSE(file_out);

EXCEPTION WHEN OTHERS THEN
        dbms_output.put_line('Error Encountered 99:' || SQLCODE || SQLERRM(SQLCODE) );
END;
/

