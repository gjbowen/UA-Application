create PACKAGE BODY         uaf_k_apay_open_alabama AS


    /*********************Global Objects *****************************************/
    v_thru_date date; --initialize
    v_from_date date; --initialize
    v_i         number;


    fh_errrpt   utl_file.file_type;
    fh_file     utl_file.file_type; --file handle
    fh_file_xml utl_file.file_type;

    type fund_ftyp_table is table of fimsmgr.ftvfund.ftvfund_ftyp_code%type
    index by fimsmgr.ftvfund.ftvfund_fund_code%type;--varchar2(20);
    v_fund_ftyp  fund_ftyp_table;

    procedure main is

        /****************************** Variables ************************************/
        v_dir      varchar2(50);
        v_file     varchar2(50); 
        v_errrpt   varchar2(50);
        v_file_xml varchar2(50);
        v_line     varchar2(1000);    
    begin
        --make the error report global for all runs:
        v_dir := '/u03/export/PROD' ;
        v_errrpt   := 'opn_ala_extrct_error_rpt.csv';
        fh_errrpt   := utl_file.fopen(v_dir, v_errrpt, 'w');    

        for i in -21..-1 loop
            v_i := i;
            v_from_date :=  trunc(last_day(add_months(sysdate,-2+i))+1);
            v_thru_date :=  trunc(last_day(add_months(sysdate,-1+i)));

            --Format the file name.       
            v_file     := to_char(v_thru_date,'YYYYMM')||'_opn_ala_extrct.txt';
            v_file_xml := to_char(v_thru_date,'YYYYMM')||'_opn_ala_extrct.xml';

            --Open it in write mode.      
            fh_file     := utl_file.fopen(v_dir, v_file, 'w');
            fh_file_xml := utl_file.fopen(v_dir, v_file_xml, 'w');

            --Run the procedure that collects all the fund type codes by fund in a
            --global collector table that we can use from anywhere.
            collect_ftyp;

            --Run the procedures that pull the data.
            --Error Report
            v_line := ',,,,Open Alabama Error Report,,,'|| to_char(v_thru_date,'mm/dd/yyyy');
            utl_file.put_line(fh_errrpt, v_line);

            --xml code
            v_line := '<?xml version="1.0" encoding="UTF-8"?>';
            utl_file.put_line(fh_file_xml, v_line);
            v_line := '<ROOT>';
            utl_file.put_line(fh_file_xml, v_line);
            -- xml code end


            pcard;
            checks;
            payroll;

            --xml code
            v_line := '</ROOT>';
            utl_file.put_line(fh_file_xml, v_line);  

            -- xml code end

            -- Close the file.
            utl_file.fclose(fh_file);
            utl_file.fclose(fh_file_xml);

            --Write a message for Appworx output.
            dbms_output.put_line( 'Files written: ' || v_dir || '/' || v_file || '.' );
        end loop;
        --close global report
        utl_file.fclose(fh_errrpt);
    end main;
  
  procedure pcard is
  
  /****************************** Variables ********************************/
  v_category   varchar2(500);
  v_agency     fimsmgr.ftvcoas.ftvcoas_title%type;
  v_funding    varchar2(500);
  v_payee      fimsmgr.fgbtrnh.fgbtrnh_trans_desc%type;
  v_trans_num  fimsmgr.fgbtrnh.fgbtrnh_trans_desc%type;

    cursor
      recs
    is
      select
        trunc(fgbtrnh_trans_date)                       trans_date, --Transaction Date
        fgbtrnh_trans_desc                              trans_desc, --Payee/Vendor Name;Transaction Number/PC Number
        fgbtrnh_acct_code                               acct_code,  --Account Code for Category
        fgbtrnh_coas_code                               coas_code,  --COAS code for Agency
        fgbtrnh_fund_code                               fund_code,  --Funding Source
        null                                            po_num,     --PO Number (not used)
        null                                            check_num,  --Check Number (not used)
--        null                                            cancel_ind, --Cancel Indicator (not used)
        ' '                                             cancel_ind, --Cancel Indicator (not used)
        decode(fgbtrnh_dr_cr_ind,'-',trim(to_char(fgbtrnh_trans_amt*-1, '99999999999999.99'))
                                ,'C',trim(to_char(fgbtrnh_trans_amt*-1, '99999999999999.99'))
                                    ,trim(to_char(fgbtrnh_trans_amt, '99999999999999.99'))) trans_amt   --Transaction Amount
      from fimsmgr.fgbtrnh
      where
        trunc(fgbtrnh_trans_date) between v_from_date and v_thru_date
        and fgbtrnh_coas_code = 'A'
        and
          (
            fgbtrnh_acct_code like '6%'
            or fgbtrnh_acct_code like '7%'
            or fgbtrnh_acct_code like '106%' 
          )
        and exclusions(fgbtrnh_acct_code, fgbtrnh_fund_code) = 'N'
        and 
          (
            nvl(upper(fgbtrnh_doc_code), 'NULL') like 'PC%'    
            or nvl(upper(fgbtrnh_doc_code), 'NULL') like 'WK%'
	        or nvl(upper(fgbtrnh_doc_code), 'NULL') like 'CC%'

          )
        and fgbtrnh_orgn_code != '150103'
        and fgbtrnh_orgn_code not like '6%';


    
  begin
  
    for rec in recs loop
    
      /* Parse the transaction description to get the payee and the transaction
      number.
      Starts With   Trans Num   Payee
      PC            1-11        12-end
      WK            1-8         9-end
      */
      if rec.trans_desc like 'PC%' then
        v_payee := substr(rec.trans_desc, 12);
        v_trans_num := substr(rec.trans_desc, 1, 11);      
      else
        --it starts with WK
        v_payee := substr(rec.trans_desc, 9);
        v_trans_num := substr(rec.trans_desc, 1, 8);      
        if v_trans_num not between '00000000' and '99999999' then
         v_trans_num := 'NULL';
        end if;
      end if;
    
      v_category := category( rec.acct_code );
      
      v_agency := agency( rec.coas_code );
      
      v_funding := funding_source( rec.fund_code );
      v_funding := v_agency;
      if v_trans_num != 'NULL' then    
       write_line
        (
          rec.trans_date,
          v_payee,
          v_category,
          v_agency,
          v_funding,
          v_trans_num,
          rec.po_num,
          rec.check_num,
          rec.cancel_ind,
          rec.trans_amt
        );
      end if;
    
    end loop;
    
  end pcard;
  
  procedure checks
  
  is
    
  /****************************** Variables ********************************/
  v_category   varchar2(500);
  v_agency     fimsmgr.ftvcoas.ftvcoas_title%type;
  v_funding    varchar2(500);
    
    cursor
      recs
    is
      select
        fabinck_check_date                             trans_date,
        decode
          (
            spriden_first_name, null,
            spriden_last_name,
            spriden_first_name || ' ' || spriden_mi || ' ' || spriden_last_name
          )                                            payee,
        farinva_acct_code                              acct_code,
        farinva_coas_code                              coas_code,
        farinva_fund_code                              fund_code,  
        fabinck_invh_code                              trans_num,
        nvl(fabinvh_pohd_code,' ')                     po_num,
        fabinck_check_num                              check_num,
        fabinck_cancel_ind                             cancel_ind,
--        ' '                                            cancel_ind, -- Not Used
        decode (fabinvh_cr_memo_ind,'Y',
          trim(to_char((farinva_appr_amt
                     - farinva_disc_amt
                     + farinva_tax_amt
                     + farinva_addl_chrg_amt)*-1,'99999999999999.99')),
          trim(to_char(farinva_appr_amt
                     - farinva_disc_amt
                     + farinva_tax_amt
                     + farinva_addl_chrg_amt,'99999999999999.99'))) trans_amt
      from
        fabinck
      inner join
        fabinvh
        on fabinvh_code = fabinck_invh_code
      inner join
        farinva
        on farinva_invh_code = fabinck_invh_code
        and farinva_coas_code = 'A'
        and
          (
            farinva_acct_code like '6%'
            or farinva_acct_code like '7%'
            or farinva_acct_code like '106%'
          )
        and exclusions(farinva_acct_code, farinva_fund_code) = 'N'
        and farinva_orgn_code != '150103'
        and farinva_orgn_code not like '6%'
        left join spriden
          on fabinvh_vend_pidm = spriden_pidm
          and spriden_change_ind is null  
        where
          trunc(fabinck_check_date) between v_from_date and v_thru_date
          and fabinck_bank_code = '21'
          and ((fabinck_cancel_ind is null)
            or (fabinck_cancel_ind != 'Y'));



    
  begin
  
    for rec in recs loop
    
      v_category := category( rec.acct_code );
      v_agency := agency( rec.coas_code );
      v_funding := funding_source( rec.fund_code );
      v_funding := v_agency;
      write_line
        (
          rec.trans_date,
          rec.payee,
          v_category,
          v_agency,
          v_funding,
          rec.trans_num,
          rec.po_num,
          rec.check_num,
          rec.cancel_ind,
          rec.trans_amt
        );
    
    end loop;
      
  end checks;
  
procedure payroll is
 cursor
  recs
   is
     select distinct
            phrhist_event_date trans_date, 
            spriden_first_name || ' ' || spriden_mi || ' ' || spriden_last_name payee, 
            'Payroll' category,
            'The University of Alabama' agency,
            'The University of Alabama' fund,
            (phrhist_year||' '||phrhist_pict_code||' '||phrhist_payno||' '||phrhist_seq_no) trans_num,
            ' ' po_num,
            phrdocm_doc_no check_num,
            ' ' cancel_ind,
            phrhist_gross - nvl((select d1.phrdedn_employee_amt
                                   from phrdedn d1
                                  where phrhist_pidm = d1.phrdedn_pidm
                                    and phrhist_year = d1.phrdedn_year
                                    and phrhist_pict_code = d1.phrdedn_pict_code
                                    and phrhist_payno = d1.phrdedn_payno
                                    and phrhist_seq_no = d1.phrdedn_seq_no
                                    and d1.phrdedn_bdca_code = '049'),0) trans_amt,
            spriden_last_name,
            spriden_first_name,
            spriden_mi 
      from payroll.phrhist, 
           saturn.spriden, 
           payroll.pebempl, 
           saturn.spbpers, 
           payroll.phrdocm
     where trunc(phrhist_event_date) between v_from_date and v_thru_date
       and phrhist_type_ind in ('C','M')
       and phrhist_gross > 0.00
       and phrhist_pidm = spriden_pidm
       and spriden_change_ind is null
       and phrhist_pidm = pebempl_pidm
       and phrhist_pidm = spbpers_pidm
       and pebempl_coas_code_home = 'A'
       and (pebempl_ecls_code not like 'D%' and
            pebempl_ecls_code not like 'E%' and
            pebempl_ecls_code not like 'K%' and 
            pebempl_ecls_code not like 'M%')
       and phrhist_pidm = phrdocm_pidm
       and phrhist_year = phrdocm_year
       and phrhist_pict_code = phrdocm_pict_code
       and phrhist_payno = phrdocm_payno
       and phrhist_seq_no = phrdocm_seq_no
     order by phrhist_event_date,
              spriden_last_name,
              spriden_first_name,
              spriden_mi;
                   

  begin
  
    for rec in recs loop
      write_line
        (
          rec.trans_date,
          rec.payee,
          rec.category,
          rec.agency,
          rec.fund,
          rec.trans_num,
          rec.po_num,
          rec.check_num,
          rec.cancel_ind,
          rec.trans_amt
        );
    
    end loop;
      
  end payroll;
  
  procedure write_line
    (
      p_date in varchar2,
      p_payee in varchar2,
      p_category in varchar2,
      p_agency in varchar2,
      p_funding in varchar2,   --Funding Source
      p_trans_num in varchar2, 
      p_po_num in varchar2,
      p_check_num in varchar2,
      p_cancel_ind in varchar2,
      p_trans_amt in varchar2
    )
  is
  
  /****************************** Variables ********************************/
  v_line       varchar2(1000);
  v_delim      varchar2(2) := chr(9);
  v_payee      varchar2(500);
  v_funding    varchar2(500);
  v_category   varchar2(500);
  v_agency     varchar2(500);
  v_err_flag   varchar2(1) := 'N';
  v_trans_num  varchar2(500);
 
  begin
   v_trans_num := p_trans_num;
   v_funding  := p_funding;
   v_agency   := p_agency;
   v_category := p_category;
   v_payee    := p_payee;
   
--Write Error Report Check   
   if substr(v_category,1,5) = 'Error' then
    v_err_flag := 'Y';
   end if;
   if substr(v_funding,1,5) = 'Error' then
    v_err_flag := 'Y';
   end if;
   if substr(v_agency,1,5) = 'Error' then
    v_err_flag := 'Y';
   end if; 
   if v_err_flag = 'Y' then
    v_line :=
      p_date || v_delim ||
      p_payee || v_delim ||
      p_category || v_delim ||
      p_agency || v_delim ||
      p_funding || v_delim ||
      v_trans_num || v_delim ||
      p_po_num || v_delim ||
      p_check_num || v_delim ||
      p_cancel_ind || v_delim ||
      p_trans_amt;
    utl_file.put_line(fh_errrpt, v_line);  
    if substr(v_category,1,5) = 'Error' then
     v_category := substr(v_category,6,60);
    end if;
    if substr(v_funding,1,5) = 'Error' then
     v_funding := substr(v_funding,6,60);
    end if;
    if substr(v_agency,1,5) = 'Error' then
     v_agency := substr(v_agency,6,60);
    end if; 
    v_err_flag := 'N';
   end if;
  
--Write Text
    v_line :=
      p_date || v_delim ||
      p_payee || v_delim ||
      v_category || v_delim ||
      v_agency || v_delim ||
      v_funding || v_delim ||
      v_trans_num || v_delim ||
      p_po_num || v_delim ||
      p_check_num || v_delim ||
      p_cancel_ind || v_delim ||
      p_trans_amt;
    utl_file.put_line(fh_file, v_line);  

--Write XML
      v_payee    := replace(v_payee,'&',';');
      v_payee    := replace(v_payee,'>',';');
      v_payee    := replace(v_payee,'<',';');
      v_payee    := replace(v_payee,'"',';');
      v_payee    := replace(v_payee,'''',';');
      v_funding  := replace(v_funding,'&',';');
      v_funding  := replace(v_funding,'<',';');
      v_funding  := replace(v_funding,'>',';');
      v_funding  := replace(v_funding,'"',';');
      v_funding  := replace(v_funding,'''',';');
      v_trans_num  := replace(v_trans_num,'&','&amp;');
      v_trans_num  := replace(v_trans_num,'<','&lt;');
      v_trans_num  := replace(v_trans_num,'>','&gt;');
      v_trans_num  := replace(v_trans_num,'"','&quot;');
      v_trans_num  := replace(v_trans_num,'''','&apos;');      
    v_line := ' <ROW>';
    utl_file.put_line(fh_file_xml, v_line);  
    v_line := '  <DATE>'||p_date||'</DATE>';
    utl_file.put_line(fh_file_xml, v_line);  
    v_line := '  <PAYEE>'||v_payee||'</PAYEE>';
    utl_file.put_line(fh_file_xml, v_line);  
    v_line := '  <CATEGORY>'||v_category||'</CATEGORY>';    
    utl_file.put_line(fh_file_xml, v_line);  
    v_line := '  <AGENCY>'||v_agency||'</AGENCY>';    
    utl_file.put_line(fh_file_xml, v_line);  
    v_line := '  <FUNDING>'||v_funding||'</FUNDING>';    
    utl_file.put_line(fh_file_xml, v_line);  
    v_line := '  <TRAN_NO>'||v_trans_num||'</TRAN_NO>';    
    utl_file.put_line(fh_file_xml, v_line);  
    v_line := '  <PO_NO>'||p_po_num||'</PO_NO>';    
    utl_file.put_line(fh_file_xml, v_line);  
    v_line := '  <CHECK_NO>'||p_check_num||'</CHECK_NO>';    
    utl_file.put_line(fh_file_xml, v_line);  
    v_line := '  <CANCEL_IND>'||p_cancel_ind||'</CANCEL_IND>';    
    utl_file.put_line(fh_file_xml, v_line);  
    v_line := '  <TRANS_AMT>'||p_trans_amt||'</TRANS_AMT>';    
    utl_file.put_line(fh_file_xml, v_line);  
    v_line := ' </ROW>';
    utl_file.put_line(fh_file_xml, v_line);  
  
  end write_line;
  
  function exclusions
    ( p_acct in varchar2,
      p_fund in varchar2
    )
  return varchar2
  is
  
  /****************************** Variables ********************************/
  v_ftyp      fimsmgr.ftvfund.ftvfund_ftyp_code%type;
  
  begin
  
    --Get the fund type for the fund.
    v_ftyp := get_ftyp(p_fund);
    
    /*This case statement answers the question "Is this an exclusion?"
    If we should exclude it, return Y. If we want to keep it, return N.*/
    case
        when p_acct like '722%'   then return 'Y';
        when p_acct like '724%'   then return 'Y';
        when p_acct =    '748021' then return 'Y';
        when p_acct like '7812%'  then return 'Y';
        when v_ftyp =    '81'     then return 'Y';
        else return 'N';
    end case;
    
  end exclusions;
  
  function category
    ( p_acct in varchar2 )
    return varchar2
  is
  
  begin
  
    case
      when p_acct like '106%' then return 'Supplies';
      when p_acct like '6%'   then return 'Benefits';
      when p_acct like '71%'  then return 'Supplies';
      when p_acct like '72%'  then return 'Travel';
      when p_acct like '73%'  then return 'Meetings and Conferences';
      when p_acct like '74%'  then return 'Service and Professional Fees';
      when p_acct like '751%' then return 'Rentals';
      when p_acct like '752%' then return 'Maintenance and Repair';
      when p_acct like '76%'  then return 'Utilities';
      when p_acct like '78%'  then return 'Other';
      when p_acct like '791%' then return 'Capital Purchases';
      when p_acct like '795%' then return 'Construction';
      when p_acct like '797%' then return 'Other Non-operating';
      when p_acct like '798%' then return 'Interest Expense';
      else return 'Error' || p_acct || '-Category???';
    end case;
      
  end category;

  function agency
    ( p_coas in varchar2 )
    return varchar2
  is
  
  cursor recs
  is select
     ftvcoas_title 
    from
      ftvcoas
    where
      ftvcoas_coas_code = p_coas
      and trunc(sysdate) >= trunc(ftvcoas_eff_date)
      and trunc(sysdate) < trunc(ftvcoas_nchg_date)
      and ftvcoas_term_date is null
      and ftvcoas_status_ind = 'A';
  
  begin
  
    for rec in recs loop
    
      if rec.ftvcoas_title is not null then
        return rec.ftvcoas_title;
      else
        return 'Error' || p_coas || '-Agency???';
      end if;
    
    end loop;    
    
  end;

  function funding_source
    (
      p_fund in varchar2
    )
    return varchar2
  
  is
  
  /****************************** Variables ********************************/
  v_ftyp      fimsmgr.ftvfund.ftvfund_ftyp_code%type;
  
  begin
  
    if p_fund = '11000' then
      return 'General Operations';
    else
      --Get the fund type for the fund.
      v_ftyp := get_ftyp(p_fund);
      --determine funding source based on fund type
      case
        when v_ftyp like '1%'
          then return 'Other - Miscellaneous Unrestricted';
        when v_ftyp like '3%'
          then return 'Auxiliaries';
        when v_ftyp like '4%'
          then return 'Loan Funds';
        when v_ftyp like '5%'
          then return 'Endowments';
        when v_ftyp like '6%'
          then return 'Endowments';
        when v_ftyp like '7%'
          then return 'Annuity  Income';
        when v_ftyp in ( '9A', '9C', '9B', '9R', '9U' )
          then return 'Capital Expenditures';
        when v_ftyp in ( '9M', '9N', '9P', '9W', '93', '92' )
          then return 'Renewal ';
        when v_ftyp in ( '9Z', '9F', '97', '96', '95', '94', '91' )
          then return 'Plant Funds';
        when v_ftyp in ( '21', '22', '23', '24', '2C' )
          then return 'Contracts and Grants';
        when v_ftyp in ( '25', '26', '27', '28', '29' )
          then return 'Other - Restricted Gifts';
        else return 'Error' || p_fund || '-Funding Source???';
      end case;
    end if;
    
  end funding_source;
  
  procedure collect_ftyp
  is
  
  /****************************** Cursors **********************************/
  cursor recs
  is select
       ftvfund_fund_code,
       ftvfund_ftyp_code
     from
       ftvfund
     where
       ftvfund_coas_code = 'A'
       and trunc(sysdate) >= trunc( ftvfund_eff_date )
       and trunc(sysdate) < trunc( ftvfund_nchg_date )
       and ftvfund_status_ind = 'A';
  
  begin
  
    --look up the fund type and add it to the global collection
    for rec in recs loop
      v_fund_ftyp(rec.ftvfund_fund_code) := rec.ftvfund_ftyp_code;
    end loop;
    
  end collect_ftyp;
  
  function get_ftyp
    (
      p_fund in varchar2
    )
  return varchar2
  is
  
  begin
  
    if v_fund_ftyp.exists(p_fund) then
      return v_fund_ftyp(p_fund);
    else
      return '**';
    end if;
    
  end get_ftyp;

END uaf_k_apay_open_alabama;
/

