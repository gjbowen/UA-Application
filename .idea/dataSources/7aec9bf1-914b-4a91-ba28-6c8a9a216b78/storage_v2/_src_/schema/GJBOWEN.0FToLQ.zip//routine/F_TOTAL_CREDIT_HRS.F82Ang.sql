create FUNCTION         f_total_credit_hrs (pidm_in    number,
                                 term_in    varchar2)
        RETURN NUMBER
    IS
        lv_tot_cred   NUMBER (9, 3) := 0;

        CURSOR sfrstcrCur (
            pidm_in    number,
            term_in    varchar2)
        IS
            SELECT *
              FROM stvrsts, sfrstcr
             WHERE     stvrsts_code = sfrstcr_rsts_code
                   AND stvrsts_incl_sect_enrl = 'Y'
                   AND sfrstcr_term_code = term_in
                   AND sfrstcr_pidm = pidm_in;

        sfrstcrRec    sfrstcrCur%ROWTYPE;

        CURSOR ssrattrCur (term_in    ssrattr.ssrattr_term_code%TYPE,
                           crn_in     ssrattr.ssrattr_crn%TYPE)
        IS
            SELECT *
              FROM ssrattr
             WHERE ssrattr_term_code = term_in AND ssrattr_crn = crn_in;

        ssrattrRec    ssrattrCur%ROWTYPE;
    BEGIN
        OPEN sfrstcrCur (pidm_in, term_in);

        LOOP
            FETCH sfrstcrCur INTO sfrstcrRec;

            IF sfrstcrCur%NOTFOUND
            THEN
                EXIT;
            END IF;


            -- Check course campus.
            IF     f_gtvsdax ('DINING_DOLLARS',
                              'CRSECAMPIN',
                              sfrstcrRec.sfrstcr_camp_code) =
                   'N'
               AND sfrstcrRec.sfrstcr_credit_hr > 0
            THEN
                sfrstcrRec.sfrstcr_credit_hr := 0;
            END IF;

            -- Check course attributes
            IF sfrstcrRec.sfrstcr_credit_hr > 0
            THEN
                OPEN ssrattrCur (sfrstcrRec.sfrstcr_term_code,
                                 sfrstcrRec.sfrstcr_crn);

                LOOP
                    FETCH ssrattrCur INTO ssrattrRec;

                    IF ssrattrCur%NOTFOUND
                    THEN
                        EXIT;
                    END IF;

                    IF f_gtvsdax ('DINING_DOLLARS',
                                  'CRSEATTREX',
                                  ssrattrRec.ssrattr_attr_code) =
                       'Y'
                    THEN
                        sfrstcrRec.sfrstcr_credit_hr := 0;
                        EXIT;
                    END IF;
                END LOOP;

                CLOSE ssrattrCur;
            END IF;

            lv_tot_cred := lv_tot_cred + sfrstcrRec.sfrstcr_credit_hr;
        END LOOP;

        CLOSE sfrstcrCur;

        RETURN lv_tot_cred;
    END ;
/

