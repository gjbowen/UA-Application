create PACKAGE         uaf_k_apay_open_alabama AS

  procedure main;
  
  procedure pcard;
  
  procedure checks;

  procedure payroll;
  
  procedure write_line
    (
      p_date in varchar2,
      p_payee in varchar2,
      p_category in varchar2,
      p_agency in varchar2,
      p_funding in varchar2,   --Funding Source
      p_trans_num in varchar2, 
      p_po_num in varchar2,
      p_check_num in varchar2,
      p_cancel_ind in varchar2,
      p_trans_amt in varchar2
    );
  
  function category(p_acct in varchar2) return varchar2;
  
  function agency(p_coas in varchar2) return varchar2;

  function funding_source( p_fund in varchar2)return varchar2;
  
  function exclusions (p_acct in varchar2, p_fund in varchar2) return varchar2;
  
  procedure collect_ftyp;
  
  function get_ftyp(p_fund in varchar2)  return varchar2;
  
END uaf_k_apay_open_alabama;
/

